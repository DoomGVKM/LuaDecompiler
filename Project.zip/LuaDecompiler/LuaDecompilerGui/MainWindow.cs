﻿using LuaDecompiler.Core;
using System;
using System.Windows.Forms;

namespace LuaDecompiler.Gui
{
    public partial class MainWindow : Form
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void DecompileButton_Click(object sender, System.EventArgs e)
        {
            try
            {
                GraphicalUserInterface.Decompile();
                while (GraphicalUserInterface.DecompilationDone)
                    OutputBox.Text = GraphicalUserInterface.OutputMessage;
            }
            catch (Exception ex)
            {
                OutputBox.Text = ex.Message;
            }
        }

        private void InputDirectoryBrowseButton_Click(object sender, System.EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Other File (*.*) |*.*|Executable (.exe) |*.exe|Dynamic Libary (.dll) |*.dll|Lua File (.lua) |*.lua";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                InputDirectoryBox.Text = openFileDialog.FileName;
                GraphicalUserInterface.InputDirectory = InputDirectoryBox.Text;
            }
        }

        private void OutputDirectoryBrowseButton_Click(object sender, System.EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                OutputDirectoryBox.Text = openFileDialog.FileName;
                GraphicalUserInterface.OutputDirectory = OutputDirectoryBox.Text;
            }
        }
    }
}
