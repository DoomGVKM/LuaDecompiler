﻿namespace LuaDecompiler.Gui
{
    partial class MainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.InputDirectoryBox = new System.Windows.Forms.TextBox();
            this.DecompileButton = new System.Windows.Forms.Button();
            this.InputDirectoryBrowseButton = new System.Windows.Forms.Button();
            this.OutputDirectoryBrowseButton = new System.Windows.Forms.Button();
            this.OutputDirectoryBox = new System.Windows.Forms.TextBox();
            this.OutputBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // InputDirectoryBox
            // 
            this.InputDirectoryBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.InputDirectoryBox.Location = new System.Drawing.Point(12, 12);
            this.InputDirectoryBox.Multiline = true;
            this.InputDirectoryBox.Name = "InputDirectoryBox";
            this.InputDirectoryBox.Size = new System.Drawing.Size(277, 27);
            this.InputDirectoryBox.TabIndex = 2;
            this.InputDirectoryBox.Text = "Input Directory";
            // 
            // DecompileButton
            // 
            this.DecompileButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DecompileButton.BackColor = System.Drawing.SystemColors.Window;
            this.DecompileButton.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.DecompileButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DecompileButton.Location = new System.Drawing.Point(12, 331);
            this.DecompileButton.Name = "DecompileButton";
            this.DecompileButton.Size = new System.Drawing.Size(341, 28);
            this.DecompileButton.TabIndex = 3;
            this.DecompileButton.Text = "Decompile";
            this.DecompileButton.UseVisualStyleBackColor = false;
            this.DecompileButton.Click += new System.EventHandler(this.DecompileButton_Click);
            // 
            // InputDirectoryBrowseButton
            // 
            this.InputDirectoryBrowseButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.InputDirectoryBrowseButton.BackColor = System.Drawing.SystemColors.Window;
            this.InputDirectoryBrowseButton.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.InputDirectoryBrowseButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.InputDirectoryBrowseButton.Location = new System.Drawing.Point(295, 12);
            this.InputDirectoryBrowseButton.Name = "InputDirectoryBrowseButton";
            this.InputDirectoryBrowseButton.Size = new System.Drawing.Size(58, 27);
            this.InputDirectoryBrowseButton.TabIndex = 4;
            this.InputDirectoryBrowseButton.Text = "Browse";
            this.InputDirectoryBrowseButton.UseVisualStyleBackColor = false;
            this.InputDirectoryBrowseButton.Click += new System.EventHandler(this.InputDirectoryBrowseButton_Click);
            // 
            // OutputDirectoryBrowseButton
            // 
            this.OutputDirectoryBrowseButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.OutputDirectoryBrowseButton.BackColor = System.Drawing.SystemColors.Window;
            this.OutputDirectoryBrowseButton.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.OutputDirectoryBrowseButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OutputDirectoryBrowseButton.Location = new System.Drawing.Point(295, 45);
            this.OutputDirectoryBrowseButton.Name = "OutputDirectoryBrowseButton";
            this.OutputDirectoryBrowseButton.Size = new System.Drawing.Size(58, 27);
            this.OutputDirectoryBrowseButton.TabIndex = 6;
            this.OutputDirectoryBrowseButton.Text = "Browse";
            this.OutputDirectoryBrowseButton.UseVisualStyleBackColor = false;
            this.OutputDirectoryBrowseButton.Click += new System.EventHandler(this.OutputDirectoryBrowseButton_Click);
            // 
            // OutputDirectoryBox
            // 
            this.OutputDirectoryBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OutputDirectoryBox.Location = new System.Drawing.Point(12, 45);
            this.OutputDirectoryBox.Multiline = true;
            this.OutputDirectoryBox.Name = "OutputDirectoryBox";
            this.OutputDirectoryBox.Size = new System.Drawing.Size(277, 27);
            this.OutputDirectoryBox.TabIndex = 5;
            this.OutputDirectoryBox.Text = "Output Directory";
            // 
            // OutputBox
            // 
            this.OutputBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.OutputBox.Location = new System.Drawing.Point(12, 78);
            this.OutputBox.Multiline = true;
            this.OutputBox.Name = "OutputBox";
            this.OutputBox.Size = new System.Drawing.Size(341, 247);
            this.OutputBox.TabIndex = 7;
            // 
            // MainWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 371);
            this.Controls.Add(this.OutputBox);
            this.Controls.Add(this.OutputDirectoryBrowseButton);
            this.Controls.Add(this.OutputDirectoryBox);
            this.Controls.Add(this.InputDirectoryBrowseButton);
            this.Controls.Add(this.DecompileButton);
            this.Controls.Add(this.InputDirectoryBox);
            this.MaximizeBox = false;
            this.Name = "MainWindow";
            this.Text = "Lua Decompiler GUI";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox InputDirectoryBox;
        private System.Windows.Forms.Button DecompileButton;
        private System.Windows.Forms.Button InputDirectoryBrowseButton;
        private System.Windows.Forms.Button OutputDirectoryBrowseButton;
        private System.Windows.Forms.TextBox OutputDirectoryBox;
        private System.Windows.Forms.TextBox OutputBox;
    }
}

