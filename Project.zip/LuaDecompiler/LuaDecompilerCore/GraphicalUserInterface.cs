﻿using LuaDecompiler.Core.Lua;
using System;
using System.Dynamic;

namespace LuaDecompiler.Core
{
    public class GraphicalUserInterface
    {
        public static string InputDirectory;
        public static string OutputDirectory;
        public static string OutputMessage;
        public static bool DecompilationDone = false;
        public static void WriteLine(object Message) => OutputMessage += "\n" + Message;
        public static void Decompile()
        {
            string[] args = { InputDirectory, OutputDirectory };
            if (args.Length < 2)
			{
				WriteLine("Must be 2 arguments (input file, output file). Drag and drop 2 files into the assembly to decompile.");
				return;
			}
            try
            {
                FileHeader header;
                Function function = null;
                using (FileReader reader = new FileReader(args[0]))
                {
                    header = reader.Header;
                    function = reader.NextFunctionBlock();
                }
                WriteLine(header);
                using (Generator gen = new Generator(args[1]))
                    gen.Write(function);
                WriteLine("Done!");
            }
            catch (Exception ex)
            {
                WriteLine("Error: " + ex);
            }
            DecompilationDone = true;
		}
    }
}
