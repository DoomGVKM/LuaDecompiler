﻿using LuaDecompiler.Core.Lua;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace LuaDecompiler.Core
{
	public struct FileHeader
	{
		public const int HeaderSize = 12;
		public const int SignatureBytes = 0x1B4C7561;
		public const byte Lua51Version = 0x51;
		public string signature; 
		public byte version; 
		public byte format;
		public bool isLittleEndian;
		public byte intSize; 
		public byte size_tSize;
		public byte instructionSize; 
		public byte lua_NumberSize;
		public bool isIntegral; 
		public override string ToString()
		{
			StringBuilder sb = new StringBuilder();
			sb.AppendFormat("signature:       {0}\n", signature);
			sb.AppendFormat("version:         {0}\n", version);
			sb.AppendFormat("format:          {0}\n", format);
			sb.AppendFormat("isLittleEndian:  {0}\n", isLittleEndian);
			sb.AppendFormat("intSize:         {0}\n", intSize);
			sb.AppendFormat("size_tSize:      {0}\n", size_tSize);
			sb.AppendFormat("instructionSize: {0}\n", instructionSize);
			sb.AppendFormat("lua_NumberSize:  {0}\n", lua_NumberSize);
			sb.AppendFormat("isIntegral:      {0}\n", isIntegral);
			return sb.ToString();
		}
	}
	public class FileReader : IDisposable
	{
		private readonly FileStream fileStream;
		private readonly BinaryReader reader;
		private FileHeader header;
		public FileHeader Header
		{
			get { return header; }
		}
		public FileReader(string file)
		{
			try
			{
				fileStream = new FileStream(file, FileMode.Open);
				reader = new BinaryReader(fileStream, Encoding.ASCII);
			}
			catch(FileNotFoundException fnfe)
			{
				Console.WriteLine("File " + file + " does not exist: " + fnfe);
				return;
			}
			ReadHeader();
		}
		public Lua.Function NextFunctionBlock()
		{
            if (fileStream.Length - 1 - fileStream.Position == 0)
				return null;
           Function data = new Lua.Function
            {
                sourceName = ReadString(),
                lineNumber = ReadInteger(header.intSize),
                lastLineNumber = ReadInteger(header.intSize),
                numUpvalues = reader.ReadByte(),
                numParameters = reader.ReadByte(),
                varArgFlag = (Lua.Function.VarArg)reader.ReadByte(),
                maxStackSize = reader.ReadByte(),
                instructions = ReadInstructions(),
                constants = ReadConstants(),
                functions = ReadFunctions(),
                sourceLinePositions = ReadLineNumbers(),
                locals = ReadLocals(),
                upvalues = ReadUpvalues()
            };
            return data;
		}
		public void Dispose()
		{
			reader.Dispose();
			fileStream.Dispose();
		}
		private void ReadHeader()
		{
			header = new FileHeader();
			List<byte> bytes = reader.ReadBytes(12).ToList();
            header.signature = new string(new char[] { (char)bytes[0], (char)bytes[1], (char)bytes[2], (char)bytes[3] });
			if(header.signature != (char)27 + "Lua")
				throw new InvalidDataException("File does not appear to be a Lua bytecode file.");
			header.version = bytes[4];
			if(header.version != FileHeader.Lua51Version)
				throw new NotImplementedException("Only Lua 5.1 is supported.");
			header.format = bytes[5];
			header.isLittleEndian = bytes[6] != 0;
			header.intSize = bytes[7];
			header.size_tSize = bytes[8];
			header.instructionSize = bytes[9];
			header.lua_NumberSize = bytes[10];
			header.isIntegral = bytes[11] != 0;
		}
		private List<Lua.Instruction> ReadInstructions()
		{
			int numInstrs = ReadInteger(header.intSize);
			List<Lua.Instruction> instrs = new List<Lua.Instruction>(numInstrs);
			for(int i = 0; i < numInstrs; ++i)
				instrs.Add(new Lua.Instruction(ReadInteger(header.instructionSize)));
			return instrs;
		}
		private List<Lua.Constant> ReadConstants()
		{
			int numConsts = ReadInteger(header.intSize);
			List<Lua.Constant> consts = new List<Lua.Constant>(numConsts);
			for(int i = 0; i < numConsts; ++i)
                switch ((Lua.LuaType)reader.ReadByte())
				{
					case Lua.LuaType.Nil:
						consts.Add(new Lua.NilConstant());
						break;
					case Lua.LuaType.Bool:
						consts.Add(new Lua.BoolConstant(reader.ReadBoolean()));
						break;
					case Lua.LuaType.Number:
						consts.Add(new Lua.NumberConstant(ReadNumber(header.lua_NumberSize)));
						break;
					case Lua.LuaType.String:
						consts.Add(new Lua.StringConstant(ReadString()));
						break;
				}
			return consts;
		}
		private List<Lua.Function> ReadFunctions()
		{
			int numFuncs = ReadInteger(header.intSize);
			List<Lua.Function> funcs = new List<Lua.Function>(numFuncs);
			for(int i = 0; i < numFuncs; ++i)
				funcs.Add(NextFunctionBlock());
			return funcs;
		}
		private List<int> ReadLineNumbers()
		{
			int numLinePos = ReadInteger(header.intSize);
			List<int> linePos = new List<int>(numLinePos);
			for(int i = 0; i < numLinePos; ++i)
				linePos.Add(ReadInteger(header.intSize) - 1);
			return linePos;
		}
		private List<Lua.Local> ReadLocals()
		{
            List<Lua.Local> locals = new List<Local>(ReadInteger(header.intSize));
			for(int i = 0; i < ReadInteger(header.intSize); ++i)
				locals.Add(new Lua.Local(ReadString(), ReadInteger(header.intSize), ReadInteger(header.intSize)));
			return locals;
		}
		private List<string> ReadUpvalues()
		{
			int numUpvalues = ReadInteger(header.intSize);
			List<string> upvalues = new List<string>((int)numUpvalues);
			for(int i = 0; i < numUpvalues; ++i)
				upvalues.Add(ReadString());
			return upvalues;
		}
		private string ReadString()
		{
            byte[] bytes = reader.ReadBytes(ReadInteger(header.size_tSize));
			char[] chars = new char[bytes.Length];
			for(int i = 0; i < bytes.Length; ++i)
				chars[i] = (char)bytes[i];
			return new string(chars);
		}
		private int ReadInteger(byte intSize)
		{
			byte[] bytes = reader.ReadBytes(intSize);
			int ret = 0;
			if(header.isLittleEndian)
				for(int i = 0; i < intSize; ++i)
					ret += bytes[i] << i * 8;
			else
				for(int i = 0; i < intSize; ++i)
					ret += bytes[i] >> i * 8;
			return ret;
		}
		private double ReadNumber(byte numSize)
		{
			byte[] bytes = reader.ReadBytes(numSize);
            double ret;
            if (numSize == 8)
				ret = BitConverter.ToDouble(bytes, 0);
			else if(numSize == 4)
				ret = BitConverter.ToSingle(bytes, 0);
			else
				throw new NotImplementedException("Uhm...");
			return ret;
		}
	}
}
