﻿using LuaDecompiler.Core.Lua;
using System;

namespace LuaDecompiler.Core
{
    public class CommandLine
    {
        public static void Decompile(string[] args)
        {
            if (args.Length < 2)
            {
                Console.WriteLine("Must be 2 arguments (input file, output file).");
                Console.ReadLine();
                return;
            }
            try
            {
                FileHeader header;
                Function function = null;
                using (FileReader reader = new FileReader(args[0]))
                {
                    header = reader.Header;
                    function = reader.NextFunctionBlock();
                }
                Console.WriteLine(header);
                using (Generator gen = new Generator(args[1]))
                    gen.Write(function);
                Console.WriteLine("\nDone!");
            }
            catch (Exception ex)
            {
                Console.WriteLine("\nError: {0}", ex);
            }
            Console.WriteLine("Press Enter to continue.");
            Console.ReadLine();
        }
    }
}
