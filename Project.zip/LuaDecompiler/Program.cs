﻿using LuaDecompiler.Core;

namespace LuaDecompiler
{
    class Program
	{
        public static void Main(string[] args) => CommandLine.Decompile(args);
    }
}
